import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/supabase_service.dart';
import 'dart:async';

class LibraryView extends StatefulWidget {
  const LibraryView({super.key});

  @override
  State<LibraryView> createState() => _LibraryViewState();
}

class _LibraryViewState extends State<LibraryView> {
  final _queryController = TextEditingController();
  final SupabaseService _supabaseService = SupabaseService();
  final ApiService _apiService = ApiService();
  StreamSubscription? _contentSubscription;

  String? _answer;
  List<Map<String, String>> _sources = [];

  @override
  void initState() {
    super.initState();
    _apiService.connect();
    _contentSubscription = _apiService.contentStream.listen((data) {
      setState(() {
        _answer = data["answer"] ?? "No answer available";
        _sources = List<Map<String, String>>.from(
          (data["sources"] ?? [])
              .map((source) => {"url": source["url"], "title": source["title"]}),
        );
      });

      // Save query and response in Supabase
      _saveQueryResponse(_queryController.text, _answer ?? "", _sources);
    });
  }

  void _saveQueryResponse(String query, String answer, List<Map<String, String>> sources) async {
    try {
      await _supabaseService.saveQueryResponse(query: query, answer: answer, sources: sources);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Query saved successfully')),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error saving query: $e')),
      );
    }
  }

  void onSubmitQuery(String userQuery) {
    if (userQuery.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a query')),
      );
      return;
    }
    _apiService.chat(userQuery);
  }

  @override
  void dispose() {
    _queryController.dispose();
    _contentSubscription?.cancel();
    _apiService.disconnect();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Perplexity Clone')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _queryController,
              decoration: const InputDecoration(
                labelText: 'Ask a question',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: () => onSubmitQuery(_queryController.text),
              child: const Text('Submit'),
            ),
            const SizedBox(height: 20),
            if (_answer != null) ...[
              Text(
                "Answer:",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Text(_answer!, style: const TextStyle(fontSize: 16)),
              const SizedBox(height: 16),
              Text(
                "Sources:",
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              ..._sources.map(
                (source) => ListTile(
                  title: Text(source['title']!),
                  subtitle: Text(source['url']!),
                  onTap: () {}, // Implement link opening if needed
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
