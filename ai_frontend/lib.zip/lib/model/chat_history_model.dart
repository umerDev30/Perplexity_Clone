class ChatHistory {
  final String query;
  final String response;
  final DateTime timestamp;

  ChatHistory({required this.query, required this.response, required this.timestamp});

  factory ChatHistory.fromJson(Map<String, dynamic> json) {
    return ChatHistory(
      query: json['query'],
      response: json['response'],
      timestamp: DateTime.parse(json['timestamp']),
    );
  }
}
