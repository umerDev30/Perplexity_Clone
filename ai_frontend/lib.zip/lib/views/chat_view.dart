import 'package:ai_frontend/services/api_service.dart';
import 'package:ai_frontend/utils/theme.dart';
import 'package:ai_frontend/widgets/build_sidebar.dart';
import 'package:ai_frontend/widgets/main_content.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class ChatView extends StatefulWidget {
  final String question;

  const ChatView({super.key, required this.question});

  @override
  State<ChatView> createState() => _ChatViewState();
}

class _ChatViewState extends State<ChatView> {
  String? imageUrl;

  @override
  void initState() {
    super.initState();
    ApiService().imageStream.listen((url) {
      setState(() {
        imageUrl = url;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          // Sidebar
          BuildSidebar(),
          kIsWeb ? SizedBox(width: 50) : SizedBox(),

          // Main content area
          MainContent(question: widget.question),

          // Image placeholder section
          kIsWeb
              ? Container(
                  width: 300,
                  height: double.infinity,
                  color: AppColors.background,
                  child: imageUrl != null
                      ? Image.network(
                          imageUrl!,
                          loadingBuilder: (context, child, loadingProgress) {
                            if (loadingProgress == null) return child;
                            return Center(
                                child:
                                    CircularProgressIndicator()); // Show a loader
                          },
                          errorBuilder: (context, error, stackTrace) {
                            return Image.asset(
                                'assets/default_placeholder.png'); // Fallback image
                          },
                          fit: BoxFit.cover,
                        )
                      : Center(
                          child: Text(
                            "No image available",
                            style: TextStyle(color: Colors.white60),
                          ),
                        ),
                )
              : SizedBox(),
        ],
      ),
    );
  }
}
