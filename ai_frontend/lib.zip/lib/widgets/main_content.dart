import 'package:ai_frontend/widgets/answer_section.dart';
import 'package:ai_frontend/widgets/source_section.dart';
import 'package:flutter/material.dart';

class MainContent extends StatelessWidget {
  final String question;
  const MainContent({super.key, required this.question});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30.0, vertical: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Question text
              _questionText(question),
              const SizedBox(height: 25),

              // Sources model
              const SourceSection(),

              const SizedBox(height: 25),
              // answer model

              AnswerSection(),

              const SizedBox(height: 25),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _questionText(String question) {
  return Text(
    question,
    style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
  );
}
