import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:web_socket_client/web_socket_client.dart';

class ApiService {
  static final _instance = ApiService._internal();
  WebSocket? _socket;

  factory ApiService() => _instance;
  ApiService._internal();

  final _searchResultController = StreamController<Map<String, dynamic>>.broadcast();
  final _contentController = StreamController<Map<String, dynamic>>.broadcast();
  final _imageController = StreamController<String?>.broadcast();
  final _connectionStateController = StreamController<bool>.broadcast();

  Stream<Map<String, dynamic>> get searchResultStream => _searchResultController.stream;
  Stream<Map<String, dynamic>> get contentStream => _contentController.stream;
  Stream<String?> get imageStream => _imageController.stream;
  Stream<bool> get connectionStateStream => _connectionStateController.stream;

  void connect() {
    if (_socket != null) {
      if (kDebugMode) print("WebSocket is already connected.");
      return;
    }

    try {
      _socket = WebSocket(Uri.parse("ws://localhost:8000/ws/chat"));
      _connectionStateController.add(true);

      _socket!.messages.listen(
        (message) {
          try {
            final data = json.decode(message);

            if (data["type"] == "search_result") {
              _searchResultController.add(data);
            } else if (data["type"] == "content") {
              _contentController.add(data);
              if (data.containsKey("image")) {
                _imageController.add(data["image"]);
              }
            }
          } catch (e) {
            if (kDebugMode) print("Error parsing message: $e");
          }
        },
        onError: (error) {
          if (kDebugMode) print("WebSocket error: $error");
          _connectionStateController.add(false);
        },
        onDone: () {
          if (kDebugMode) print("WebSocket connection closed");
          _connectionStateController.add(false);
          _socket = null;
        },
      );
    } catch (e) {
      if (kDebugMode) print("Error connecting to WebSocket: $e");
      _connectionStateController.add(false);
    }
  }

  void disconnect() {
    _socket?.close();
    _connectionStateController.add(false);
    _socket = null;
    if (kDebugMode) print("WebSocket disconnected");
  }

  void chat(String query) {
    if (_socket == null) {
      if (kDebugMode) print("WebSocket is not connected.");
      return;
    }

    try {
      _socket!.send(json.encode({"query": query}));
    } catch (e) {
      if (kDebugMode) print("Error sending message: $e");
    }
  }

  void dispose() {
    _searchResultController.close();
    _contentController.close();
    _imageController.close();
    _connectionStateController.close();
    disconnect();
  }
}
