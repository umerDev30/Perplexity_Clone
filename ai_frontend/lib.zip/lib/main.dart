import 'package:ai_frontend/utils/theme.dart';
import 'package:ai_frontend/views/home_view.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          scaffoldBackgroundColor: AppColors.background,
          colorScheme: ColorScheme.fromSeed(seedColor: AppColors.submitButton),
          textTheme:
              GoogleFonts.interTextTheme(ThemeData.dark().textTheme.copyWith(
                    bodyMedium:
                        TextStyle(fontSize: 16, color: AppColors.whiteColor),
                  )),
        ),
        home: HomeView());
  }
}
